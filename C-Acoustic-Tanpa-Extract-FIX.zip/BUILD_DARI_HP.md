# CARA BUILD APK LANGSUNG DARI HP ANDROID INI

## Opsi 1: GitHub Actions (PALING GAMPANG - Tanpa PC)
1. Upload ZIP repo ini ke GitHub (github.com/new)
2. Buat repo `c-acoustic-android` -> Upload files -> Commit
3. Buka tab **Actions** di repo kamu
4. Tunggu 3-5 menit, workflow "Build C Acoustic APK" akan jalan otomatis
5. Kalau sudah hijau (centang), buka Actions -> Klik build terakhir -> Download di bagian **Artifacts -> C-Acoustic-APK**
6. File `app-debug.apk` ada di dalam ZIP artifact -> Install di HP kamu langsung
7. APK akan pakai Logo CAND TECH Fix Transparan + White Theme

Setiap kamu push update code, APK baru otomatis ke-build lagi!

## Opsi 2: Pakai AIDE di HP (Offline)
- Install AIDE - IDE for Android di Play Store
- Clone repo ini atau import ZIP
- Open project -> Run

## Opsi 3: Pakai CodeSpaces di HP
- Di GitHub repo, tekan tombol **Code -> Codespaces -> Create**
- Buka VSCode di browser HP
- Jalankan: ./gradlew assembleDebug
- Download APK dari app/build/outputs/apk/debug/

## Catatan
- APK debug butuh izin RECORD_AUDIO dan USB OTG untuk soundcard external
- Logo sudah fix: gradien hitam tengah ada, background luar transparan
