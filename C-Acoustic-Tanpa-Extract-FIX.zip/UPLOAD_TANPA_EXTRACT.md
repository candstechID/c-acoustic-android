# UPLOAD 1 FILE ZIP SAJA - TANPA EXTRACT

1. Download ZIP ini
2. github.com/new -> buat repo c-acoustic-android
3. Add file -> Upload files -> DRAG 1 FILE ZIP INI SAJA
4. Commit
5. Buka tab Actions -> Tunggu 3-5 menit -> Download APK di Artifacts

Workflow akan auto extract ZIP kamu di server GitHub, gak perlu extract di HP.
