
package com.candtech.acoustic.ui
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.candtech.acoustic.R

@Composable
fun TopBarWithLogo() {
    Surface(color = Color.White, shadowElevation = 2.dp) {
        Row(modifier = Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Image(painter = painterResource(id = R.drawable.cand_tech_logo), contentDescription = "CAND TECH", modifier = Modifier.height(36.dp))
            Spacer(modifier = Modifier.width(16.dp))
            Text("C ACOUSTIC - Speaker Tuning", color = Color.Black)
            Spacer(modifier = Modifier.weight(1f))
            UsbDeviceSelector()
        }
    }
}
@Composable fun UsbDeviceSelector() { Text("USB: Internal Mic", color = Color.Gray) }
