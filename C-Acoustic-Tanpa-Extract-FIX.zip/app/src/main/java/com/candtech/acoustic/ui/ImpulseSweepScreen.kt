
package com.candtech.acoustic.ui
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
@Composable fun ImpulseSweepScreen() {
    var sweeping by remember { mutableStateOf(false) }
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("IMPULSE RESPONSE - Sine Sweep 20Hz-20kHz", color = Color.Black)
        Text("No Phantom Power | External Soundcard Only", color = Color.Gray)
        Spacer(Modifier.height(16.dp))
        Button(onClick = { sweeping = !sweeping }) { Text(if(sweeping) "STOP SWEEP" else "START SWEEP 8s") }
        Text("Delay: -- ms / -- m | ETC | Export WAV IR", color = Color.Black)
    }
}
