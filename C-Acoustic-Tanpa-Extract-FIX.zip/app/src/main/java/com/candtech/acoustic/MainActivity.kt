package com.candtech.acoustic

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.candtech.acoustic.ui.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    background = Color.White,
                    surface = Color.White
                )
            ) {
                var selectedTab by remember { mutableStateOf(0) }
                val tabs = listOf("RTA", "TRANSFER", "IMPULSE SWEEP", "AUTO PHASE", "AUTO EQ")
                
                Scaffold(
                    topBar = { TopBarWithLogo() },
                    bottomBar = {
                        TabRow(selectedTabIndex = selectedTab) {
                            tabs.forEachIndexed { index, title ->
                                Tab(selected = selectedTab == index, onClick = { selectedTab = index }, text = { Text(title) })
                            }
                        }
                    },
                    containerColor = Color.White
                ) { padding ->
                    Box(modifier = Modifier.padding(padding).fillMaxSize()) {
                        when(selectedTab) {
                            0 -> RTAScreen()
                            1 -> TransferFunctionScreen()
                            2 -> ImpulseSweepScreen()
                            3 -> AutoPhaseScreen()
                            4 -> AutoEQScreen()
                        }
                    }
                }
            }
        }
    }
}
