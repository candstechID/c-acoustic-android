#include <jni.h>
#include <android/log.h>
#define LOG_TAG "CANDS_DSP_NATIVE"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

extern "C" JNIEXPORT void JNICALL Java_com_candtech_acoustic_dsp_AudioEngine_init(JNIEnv* env, jobject) {
    LOGI("AudioEngine C++ Native Initialized successfully.");
}
