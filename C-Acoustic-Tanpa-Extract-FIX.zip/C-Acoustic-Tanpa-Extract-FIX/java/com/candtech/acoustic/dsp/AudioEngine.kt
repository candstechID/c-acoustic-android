package com.candtech.acoustic.dsp
import android.util.Log

object AudioEngine {
    private const val TAG = "CANDS_DSP"
    init {
        try {
            System.loadLibrary("cacoustic")
            Log.i(TAG, "Native library cacoustic loaded successfully.")
        } catch (e: UnsatisfiedLinkError) {
            Log.e(TAG, "Failed to load native library cacoustic: ${e.message}")
        }
    }
    external fun init()
}
