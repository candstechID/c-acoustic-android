// Impulse Sweep Response Module
