// Auto Phase Alignment Module
