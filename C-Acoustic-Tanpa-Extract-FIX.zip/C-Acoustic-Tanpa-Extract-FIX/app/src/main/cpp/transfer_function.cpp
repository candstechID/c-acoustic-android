// Transfer Function (Dual Channel Measurement) Module
