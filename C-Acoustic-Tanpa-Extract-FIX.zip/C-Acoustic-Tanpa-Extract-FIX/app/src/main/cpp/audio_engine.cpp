#include <jni.h>
extern "C" JNIEXPORT void JNICALL Java_com_candtech_acoustic_dsp_AudioEngine_init(JNIEnv* env, jobject) {}
