// CANDSTECH Audio Engine Core
#include <jni.h>
#include <string>

extern "C" JNIEXPORT jstring JNICALL
Java_com_candtech_acoustic_MainActivity_stringFromJNI(JNIEnv* env, jobject /* this */) {
    std::string hello = "CANDSTECH DSP Engine Initialized";
    return env->NewStringUTF(hello.c_str());
}
