// Auto EQ Parametric Processing Module
