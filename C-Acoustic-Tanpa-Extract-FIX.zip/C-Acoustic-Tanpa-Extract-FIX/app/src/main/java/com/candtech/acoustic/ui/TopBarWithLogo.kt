package com.candtech.acoustic.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.candtech.acoustic.R

@Composable
fun TopBarWithLogo() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.White)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Image(
            painter = painterResource(id = R.drawable.cand_tech_logo),
            contentDescription = "CANDSTECH Logo",
            modifier = Modifier
                .height(42.dp)
                .background(Color.Transparent) 
        )
        Text(
            text = "RTA | TRANSFER FUNCTION | AUTO EQ",
            color = Color.Black,
            fontWeight = FontWeight.Bold
        )
    }
}
