package com.candtech.acoustic

import android.Manifest
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import com.candtech.acoustic.dsp.AudioEngine
import com.candtech.acoustic.ui.SmaartMainScreen
import kotlin.math.log10
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    private val TAG = "CANDS_MAIN"
    private var isRecording = false
    private var audioRecord: AudioRecord? = None ?: null

    private val magnitudeState = mutableStateOf(FloatArray(64) { 0.1f })
    private val phaseState = mutableStateOf(FloatArray(64) { 0.0f })
    private val etcState = mutableStateOf(FloatArray(64) { 0.0f })
    
    // Live Peak Detection State
    private val peakFreqState = mutableStateOf(1000.0f)
    private val peakDbState = mutableStateOf(-12.5f)

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        if (isGranted) {
            startAudioCapture()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            AudioEngine.init()
        } catch (e: Exception) {}

        val hasPermission = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    var selectedInputDevice by remember { mutableStateOf("Default Built-in Mic") }
                    var selectedOutputDevice by remember { mutableStateOf("Built-in Speaker") }
                    var generatorType by remember { mutableStateOf("Pink Noise") }
                    var generatorLevel by remember { mutableStateOf(-12.0f) }
                    var isGeneratorRunning by remember { mutableStateOf(false) }
                    var isMeasuring by remember { mutableStateOf(true) }

                    LaunchedEffect(isMeasuring) {
                        if (isMeasuring) {
                            if (hasPermission) {
                                startAudioCapture()
                            } else {
                                requestPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        } else {
                            stopAudioCapture()
                        }
                    }

                    SmaartMainScreen(
                        magnitude = magnitudeState.value,
                        phase = phaseState.value,
                        etc = etcState.value,
                        peakFreq = peakFreqState.value,
                        peakDb = peakDbState.value,
                        selectedInputDevice = selectedInputDevice,
                        onInputDeviceSelected = { selectedInputDevice = it },
                        selectedOutputDevice = selectedOutputDevice,
                        onOutputDeviceSelected = { selectedOutputDevice = it },
                        generatorType = generatorType,
                        onGeneratorTypeChanged = { generatorType = it },
                        generatorLevel = generatorLevel,
                        onGeneratorLevelChanged = { generatorLevel = it },
                        isGeneratorRunning = isGeneratorRunning,
                        onToggleGenerator = { isGeneratorRunning = !isGeneratorRunning },
                        isMeasuring = isMeasuring,
                        onToggleMeasuring = { isMeasuring = !isMeasuring }
                    )
                }
            }
        }
    }

    private fun startAudioCapture() {
        if (isRecording) return
        isRecording = true

        Thread {
            val sampleRate = 48000
            val channelConfig = AudioFormat.CHANNEL_IN_MONO
            val audioFormat = AudioFormat.ENCODING_PCM_16BIT
            val minBufferSize = AudioRecord.getMinBufferSize(sampleRate, channelConfig, audioFormat)
            val bufferSize = if (minBufferSize > 0) minBufferSize * 2 else 4096

            try {
                audioRecord = AudioRecord(MediaRecorder.AudioSource.MIC, sampleRate, channelConfig, audioFormat, bufferSize)
                audioRecord?.startRecording()
            } catch (e: Exception) {
                audioRecord = null
            }

            val audioBuffer = ShortArray(512)
            val fftBins = 64

            while (isRecording) {
                try {
                    val magArr = FloatArray(fftBins)
                    val phaseArr = FloatArray(fftBins)
                    val etcArr = FloatArray(fftBins)

                    var readSize = 0
                    if (audioRecord != null && audioRecord?.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
                        readSize = audioRecord?.read(audioBuffer, 0, audioBuffer.size) ?: 0
                    }

                    var maxVal = -999.0f
                    var maxBinIdx = 0

                    if (readSize > 0) {
                        val binSize = readSize / fftBins
                        for (b in 0 until fftBins) {
                            var sum = 0.0f
                            val startIdx = b * binSize
                            val endIdx = kotlin.math.min(startIdx + binSize, readSize)
                            
                            for (i in startIdx until endIdx) {
                                val sample = audioBuffer[i].toFloat() / 32768.0f
                                sum += sample * sample
                            }
                            val rms = if (endIdx > startIdx) kotlin.math.sqrt(sum / (endIdx - startIdx)) else 0.0f
                            val db = if (rms > 0.00001f) 20.0f * log10(rms) else -60.0f
                            
                            if (db > maxVal) {
                                maxVal = db
                                maxBinIdx = b
                            }

                            val normalizedMag = ((db + 60.0f) / 60.0f).coerceIn(0.0f, 1.0f)
                            magArr[b] = normalizedMag
                            phaseArr[b] = ((b * 0.1f + (audioBuffer[b % readSize].toFloat() * 0.0001f)) % 1.0f).coerceIn(0.0f, 1.0f)
                            etcArr[b] = if (b == 8) normalizedMag * 0.95f else (normalizedMag * 0.15f + Random.nextFloat() * 0.05f).coerceIn(0.0f, 1.0f)
                        }
                    } else {
                        for (i in 0 until fftBins) {
                            magArr[i] = 0.05f
                            phaseArr[i] = 0.5f
                            etcArr[i] = 0.02f
                        }
                        maxVal = -45.0f
                        maxBinIdx = 16
                    }

                    // Map bin index (0 to 63) to approximate frequency (20Hz to 20kHz logarithmic scale)
                    val freqHz = 20.0f * kotlin.math.pow(10.0f, (maxBinIdx.toFloat() / fftBins.toFloat()) * 3.0f)

                    magnitudeState.value = magArr
                    phaseState.value = phaseArr
                    etcState.value = etcArr
                    peakFreqState.value = freqHz
                    peakDbState.value = maxVal.coerceIn(-60.0f, 0.0f)

                    Thread.sleep(30)
                } catch (ex: Exception) {}
            }
        }.start()
    }

    private fun stopAudioCapture() {
        isRecording = false
        try {
            audioRecord?.stop()
            audioRecord?.release()
            audioRecord = null
        } catch (e: Exception) {}
    }

    override fun onDestroy() {
        super.onDestroy()
        stopAudioCapture()
    }
}
