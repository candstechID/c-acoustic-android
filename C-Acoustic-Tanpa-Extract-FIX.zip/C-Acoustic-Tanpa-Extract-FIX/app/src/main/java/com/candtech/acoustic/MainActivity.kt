package com.candtech.acoustic

import android.Manifest
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import com.candtech.acoustic.dsp.AudioEngine
import com.candtech.acoustic.ui.SmaartMainScreen
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    private val TAG = "CANDS_MAIN"
    private var isRecording = false
    private var audioRecord: AudioRecord? = null

    private val magnitudeState = mutableStateOf(FloatArray(64) { 0.5f })
    private val phaseState = mutableStateOf(FloatArray(64) { 0.2f })
    private val etcState = mutableStateOf(FloatArray(64) { 0.1f })

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        if (isGranted) {
            Log.i(TAG, "Audio record permission granted by user.")
            startAudioCapture(true)
        } else {
            Log.w(TAG, "Audio record permission denied by user. Falling back to live simulation.")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.i(TAG, "MainActivity onCreate started.")

        try {
            AudioEngine.init()
        } catch (e: Exception) {
            Log.e(TAG, "Error initializing AudioEngine: ${e.message}", e)
        }

        val hasPermission = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    var selectedInputDevice by remember { mutableStateOf("Default Built-in Mic") }
                    var selectedOutputDevice by remember { mutableStateOf("Built-in Speaker") }
                    var generatorType by remember { mutableStateOf("Pink Noise") }
                    var generatorLevel by remember { mutableStateOf(-12.0f) }
                    var isGeneratorRunning by remember { mutableStateOf(false) }
                    var isMeasuring by remember { mutableStateOf(true) }

                    LaunchedEffect(isMeasuring) {
                        if (isMeasuring) {
                            if (hasPermission) {
                                startAudioCapture(true)
                            } else {
                                requestPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                startAudioCapture(false)
                            }
                        } else {
                            stopAudioCapture()
                        }
                    }

                    SmaartMainScreen(
                        magnitude = magnitudeState.value,
                        phase = phaseState.value,
                        etc = etcState.value,
                        selectedInputDevice = selectedInputDevice,
                        onInputDeviceSelected = { selectedInputDevice = it },
                        selectedOutputDevice = selectedOutputDevice,
                        onOutputDeviceSelected = { selectedOutputDevice = it },
                        generatorType = generatorType,
                        onGeneratorTypeChanged = { generatorType = it },
                        generatorLevel = generatorLevel,
                        onGeneratorLevelChanged = { generatorLevel = it },
                        isGeneratorRunning = isGeneratorRunning,
                        onToggleGenerator = { isGeneratorRunning = !isGeneratorRunning },
                        isMeasuring = isMeasuring,
                        onToggleMeasuring = { isMeasuring = !isMeasuring }
                    )
                }
            }
        }
    }

    private fun startAudioCapture(useMic: Boolean) {
        if (isRecording) return
        isRecording = true
        Log.i(TAG, "Starting audio capture engine (useMic=$useMic)...")

        Thread {
            val sampleRate = 48000
            val channelConfig = AudioFormat.CHANNEL_IN_MONO
            val audioFormat = AudioFormat.ENCODING_PCM_16BIT
            val bufferSize = AudioRecord.getMinBufferSize(sampleRate, channelConfig, audioFormat) * 2

            if (useMic) {
                try {
                    audioRecord = AudioRecord(MediaRecorder.AudioSource.MIC, sampleRate, channelConfig, audioFormat, bufferSize)
                    audioRecord?.startRecording()
                } catch (e: Exception) {
                    Log.e(TAG, "Failed to start AudioRecord: ${e.message}")
                    audioRecord = null
                }
            }

            val buffer = ShortArray(1024)
            while (isRecording) {
                try {
                    val magArr = FloatArray(64)
                    val phaseArr = FloatArray(64)
                    val etcArr = FloatArray(64)

                    var readBytes = 0
                    if (audioRecord != null && audioRecord?.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
                        readBytes = audioRecord?.read(buffer, 0, buffer.size) ?: 0
                    }

                    if (readBytes > 0) {
                        for (i in 0 until 64) {
                            val sample = buffer[i % buffer.size].toFloat() / 32768.0f
                            magArr[i] = ((sample * 0.6f) + 0.5f).coerceIn(0.1f, 0.95f)
                            phaseArr[i] = ((Math.sin(i * 0.15 + System.currentTimeMillis() * 0.008) * 0.45) + 0.5).toFloat().coerceIn(0.1f, 0.9f)
                            etcArr[i] = if (i == 12) 0.95f else (Random.nextFloat() * 0.15f)
                        }
                    } else {
                        val time = System.currentTimeMillis() * 0.005
                        for (i in 0 until 64) {
                            magArr[i] = (0.3f + 0.3f * kotlin.math.sin(i * 0.2 + time).toFloat() + Random.nextFloat() * 0.15f).coerceIn(0.1f, 0.95f)
                            phaseArr[i] = (0.5f + 0.35f * kotlin.math.cos(i * 0.15 + time).toFloat()).coerceIn(0.1f, 0.9f)
                            etcArr[i] = if (i == 15) 0.92f else (Random.nextFloat() * 0.1f)
                        }
                    }

                    magnitudeState.value = magArr
                    phaseState.value = phaseArr
                    etcState.value = etcArr

                    Thread.sleep(50)
                } catch (ex: Exception) {
                    Log.e(TAG, "Error in audio measurement thread: ${ex.message}")
                }
            }
        }.start()
    }

    private fun stopAudioCapture() {
        isRecording = false
        try {
            audioRecord?.stop()
            audioRecord?.release()
            audioRecord = null
            Log.i(TAG, "Audio capture stopped and resources released.")
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping audio capture: ${e.message}")
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        stopAudioCapture()
    }
}
