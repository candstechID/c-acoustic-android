package com.candtech.acoustic

import android.Manifest
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import com.candtech.acoustic.ui.SmaartMainScreen

class MainActivity : ComponentActivity() {
    private var isRecording = false
    private var audioRecord: AudioRecord? = null

    private val magnitudeState = mutableStateOf(FloatArray(64) { 0.5f })
    private val phaseState = mutableStateOf(FloatArray(64) { 0.2f })
    private val etcState = mutableStateOf(FloatArray(64) { 0.1f })

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        if (isGranted) startAudioCapture()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startAudioCapture()
        } else {
            requestPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }

        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    var selectedInputDevice by remember { mutableStateOf("Default Built-in Mic") }
                    var selectedOutputDevice by remember { mutableStateOf("Built-in Speaker") }
                    var generatorType by remember { mutableStateOf("Pink Noise") }
                    var generatorLevel by remember { mutableStateOf(-12.0f) }
                    var isGeneratorRunning by remember { mutableStateOf(false) }

                    SmaartMainScreen(
                        magnitude = magnitudeState.value,
                        phase = phaseState.value,
                        etc = etcState.value,
                        selectedInputDevice = selectedInputDevice,
                        onInputDeviceSelected = { selectedInputDevice = it },
                        selectedOutputDevice = selectedOutputDevice,
                        onOutputDeviceSelected = { selectedOutputDevice = it },
                        generatorType = generatorType,
                        onGeneratorTypeChanged = { generatorType = it },
                        generatorLevel = generatorLevel,
                        onGeneratorLevelChanged = { generatorLevel = it },
                        isGeneratorRunning = isGeneratorRunning,
                        onToggleGenerator = { isGeneratorRunning = !isGeneratorRunning }
                    )
                }
            }
        }
    }

    private fun startAudioCapture() {
        if (isRecording) return
        val sampleRate = 48000
        val channelConfig = AudioFormat.CHANNEL_IN_MONO
        val audioFormat = AudioFormat.ENCODING_PCM_16BIT
        val bufferSize = AudioRecord.getMinBufferSize(sampleRate, channelConfig, audioFormat) * 2

        try {
            audioRecord = AudioRecord(MediaRecorder.AudioSource.MIC, sampleRate, channelConfig, audioFormat, bufferSize)
            audioRecord?.startRecording()
            isRecording = true

            Thread {
                val buffer = ShortArray(1024)
                while (isRecording) {
                    val readResult = audioRecord?.read(buffer, 0, buffer.size) ?: 0
                    if (readResult > 0) {
                        val magArr = FloatArray(64)
                        val phaseArr = FloatArray(64)
                        val etcArr = FloatArray(64)

                        for (i in 0 until 64) {
                            val sample = buffer[i % buffer.size] / 32768.0f
                            magArr[i] = ((sample * 0.5f) + 0.5f).coerceIn(0f, 1f)
                            phaseArr[i] = ((Math.sin(i * 0.1 + System.currentTimeMillis() * 0.005) * 0.4f) + 0.5f).toFloat()
                            etcArr[i] = if (i == 10) 0.9f else (Math.random() * 0.1f).toFloat()
                        }

                        magnitudeState.value = magArr
                        phaseState.value = phaseArr
                        etcState.value = etcArr
                    }
                }
            }.start()
        } catch (e: SecurityException) {
            e.printStackTrace()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        isRecording = false
        audioRecord?.stop()
        audioRecord?.release()
    }
}
