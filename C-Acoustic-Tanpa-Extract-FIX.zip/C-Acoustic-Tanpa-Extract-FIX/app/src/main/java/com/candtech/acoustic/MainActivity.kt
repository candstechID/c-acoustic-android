package com.candtech.acoustic

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.candtech.acoustic.ui.RTAScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    // Data simulasi untuk menguji visualizer
                    val dummyAmplitudes = FloatArray(31) { (Math.random() * 0.8).toFloat() }
                    val dummyPeaks = FloatArray(31) { (Math.random() * 0.9 + 0.1).toFloat() }
                    RTAScreen(dummyAmplitudes, dummyPeaks)
                }
            }
        }
    }
}
