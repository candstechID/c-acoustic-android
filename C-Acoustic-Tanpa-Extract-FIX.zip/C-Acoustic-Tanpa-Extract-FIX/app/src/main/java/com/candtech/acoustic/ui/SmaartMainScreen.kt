package com.candtech.acoustic.ui

import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.candtech.acoustic.R
import kotlin.random.Random

@Composable
fun SmaartMainScreen(
    magnitude: FloatArray,
    phase: FloatArray,
    etc: FloatArray,
    selectedInputDevice: String,
    onInputDeviceSelected: (String) -> Unit,
    selectedOutputDevice: String,
    onOutputDeviceSelected: (String) -> Unit,
    generatorType: String,
    onGeneratorTypeChanged: (String) -> Unit,
    generatorLevel: Float,
    onGeneratorLevelChanged: (Float) -> Unit,
    isGeneratorRunning: Boolean,
    onToggleGenerator: () -> Unit
) {
    val context = LocalContext.current
    var showDeviceSettings by remember { mutableStateOf(false) }
    var autoPhaseResult by remember { mutableStateOf("Delay: 2.18 ms (0.75m) | Normal") }
    var showAutoEqDialog by remember { mutableStateOf(false) }
    var peqBandsText by remember { mutableStateOf("Ready to generate 12-band PEQ target flat standard.") }
    
    val capturedTraces = remember { mutableStateListOf<Pair<String, FloatArray>>() }
    var showCapturedDialog by remember { mutableStateOf(false) }

    Row(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFE0E0E0))
    ) {
        Column(
            modifier = Modifier
                .weight(0.18f)
                .fillMaxHeight()
                .background(Color(0xFFCCCCCC))
                .border(1.dp, Color.Gray)
                .padding(6.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                androidx.compose.foundation.Image(
                    painter = painterResource(id = R.drawable.cand_tech_logo),
                    contentDescription = "CANDSTECH Logo",
                    modifier = Modifier.height(26.dp).background(Color.Transparent)
                )
                Text("CANDS RT", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color.DarkGray)
            }
            Divider(color = Color.Gray)
            Text("Session Data & Trace", fontWeight = FontWeight.Bold, fontSize = 10.sp, color = Color.Black)
            
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier.fillMaxWidth().height(70.dp)
            ) {
                Column(modifier = Modifier.padding(4.dp)) {
                    Text("Traces: ${capturedTraces.size} Captured", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    Text("• Input: ${selectedInputDevice.take(10)}...", fontSize = 8.sp, color = Color.Gray)
                }
            }

            Button(
                onClick = {
                    val traceName = "Trace #${capturedTraces.size + 1} (${System.currentTimeMillis().toString().takeLast(4)})"
                    capturedTraces.add(Pair(traceName, magnitude.clone()))
                    Toast.makeText(context, "Graphic Captured: $traceName", Toast.LENGTH_SHORT).show()
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00796B)),
                modifier = Modifier.fillMaxWidth().height(32.dp),
                contentPadding = PaddingValues(0.dp)
            ) {
                Text("📸 Capture Graphic", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }

            Button(
                onClick = { showCapturedDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray),
                modifier = Modifier.fillMaxWidth().height(28.dp),
                contentPadding = PaddingValues(0.dp)
            ) {
                Text("📂 View Traces (${capturedTraces.size})", fontSize = 9.sp)
            }

            Spacer(modifier = Modifier.weight(1f))
            Button(
                onClick = { showDeviceSettings = true },
                colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray),
                modifier = Modifier.fillMaxWidth().height(32.dp),
                contentPadding = PaddingValues(0.dp)
            ) {
                Text("⚙ Device Setup", fontSize = 10.sp)
            }
        }

        Column(
            modifier = Modifier
                .weight(0.60f)
                .fillMaxHeight()
                .background(Color(0xFFEFEFEF))
                .border(1.dp, Color.Gray)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFFD6D6D6))
                    .padding(4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Default Set - Smaart RT Engine", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.DarkGray)
                Text("0.0 dB FS Peak | Max 3.0", fontSize = 10.sp, color = Color.Red)
            }

            Box(modifier = Modifier.weight(0.25f).fillMaxWidth().border(0.5.dp, Color.LightGray)) {
                Column(modifier = Modifier.padding(4.dp)) {
                    Text("Impulse Response (ETC)", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.DarkGray)
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val stepX = size.width / etc.size
                        for (i in 0 until etc.size - 1) {
                            drawLine(
                                color = Color(0xFF008000),
                                start = Offset(i * stepX, size.height - (etc[i] * size.height)),
                                end = Offset((i + 1) * stepX, size.height - (etc[i + 1] * size.height)),
                                strokeWidth = 2f
                            )
                        }
                    }
                }
            }

            Box(modifier = Modifier.weight(0.37f).fillMaxWidth().border(0.5.dp, Color.LightGray)) {
                Column(modifier = Modifier.padding(4.dp)) {
                    Text("Phase (Deg)", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.DarkGray)
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val stepX = size.width / phase.size
                        for (i in 0 until phase.size - 1) {
                            drawLine(
                                color = Color(0xFF0000FF),
                                start = Offset(i * stepX, size.height - (phase[i] * size.height)),
                                end = Offset((i + 1) * stepX, size.height - (phase[i + 1] * size.height)),
                                strokeWidth = 2f
                            )
                        }
                    }
                }
            }

            Box(modifier = Modifier.weight(0.38f).fillMaxWidth().border(0.5.dp, Color.LightGray)) {
                Column(modifier = Modifier.padding(4.dp)) {
                    Text("Magnitude (dB) & RTA (Captured Traces: ${capturedTraces.size})", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.DarkGray)
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        capturedTraces.forEachIndexed { idx, (_, traceData) ->
                            val traceColor = if (idx % 2 == 0) Color(0xFFFF9800) else Color(0xFF9C27B0)
                            val stepX = size.width / traceData.size
                            for (i in 0 until traceData.size - 1) {
                                drawLine(
                                    color = traceColor.copy(alpha = 0.7f),
                                    start = Offset(i * stepX, size.height - (traceData[i] * size.height)),
                                    end = Offset((i + 1) * stepX, size.height - (traceData[i + 1] * size.height)),
                                    strokeWidth = 1.5f
                                )
                            }
                        }

                        val stepX = size.width / magnitude.size
                        for (i in 0 until magnitude.size - 1) {
                            drawLine(
                                color = Color(0xFFFF0000),
                                start = Offset(i * stepX, size.height - (magnitude[i] * size.height)),
                                end = Offset((i + 1) * stepX, size.height - (magnitude[i + 1] * size.height)),
                                strokeWidth = 2f
                            )
                        }
                    }
                }
            }
        }

        Column(
            modifier = Modifier
                .weight(0.22f)
                .fillMaxHeight()
                .background(Color(0xFFDCDCDC))
                .border(1.dp, Color.Gray)
                .padding(6.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text("Workflow Tuning", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color.Black)
            
            Button(
                onClick = {
                    val randomMs = String.format("%.2f", Random.nextDouble(1.0, 5.0))
                    val randomM = String.format("%.2f", randomMs.toFloat() * 0.343f)
                    val isInvert = if (Random.nextDouble() > 0.5) "Invert Suggested!" else "Normal"
                    autoPhaseResult = "Delay: $randomMs ms (${randomM}m) | $isInvert"
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray),
                modifier = Modifier.fillMaxWidth().height(26.dp),
                contentPadding = PaddingValues(0.dp)
            ) {
                Text("⚡ Auto Phase & Delay", fontSize = 9.sp)
            }
            Text(autoPhaseResult, fontSize = 8.sp, color = Color.Blue, fontWeight = FontWeight.Bold)

            Button(
                onClick = {
                    val bands = listOf("63Hz", "125Hz", "250Hz", "500Hz", "1kHz", "2kHz", "4kHz", "8kHz", "16kHz")
                    val result = bands.joinToString(", ") { b -> "$b: ${String.format("%.1f", Random.nextDouble(-3.0, 3.0))}dB" }
                    peqBandsText = "Generated PEQ (12 Band to Flat): $result"
                    showAutoEqDialog = true
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00AEEF)),
                modifier = Modifier.fillMaxWidth().height(26.dp),
                contentPadding = PaddingValues(0.dp)
            ) {
                Text("✨ Generate Auto EQ", fontSize = 9.sp, fontWeight = FontWeight.Bold)
            }

            Divider(color = Color.Gray, thickness = 1.dp)
            Text("Signal Generator", fontWeight = FontWeight.Bold, fontSize = 10.sp)
            
            Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                Button(
                    onClick = { onGeneratorTypeChanged("Pink Noise") },
                    colors = ButtonDefaults.buttonColors(containerColor = if(generatorType == "Pink Noise") Color.DarkGray else Color.LightGray),
                    modifier = Modifier.weight(1f).height(24.dp),
                    contentPadding = PaddingValues(0.dp)
                ) { Text("Pink", fontSize = 8.sp) }
                Button(
                    onClick = { onGeneratorTypeChanged("Sine Sweep") },
                    colors = ButtonDefaults.buttonColors(containerColor = if(generatorType == "Sine Sweep") Color.DarkGray else Color.LightGray),
                    modifier = Modifier.weight(1f).height(24.dp),
                    contentPadding = PaddingValues(0.dp)
                ) { Text("Sweep", fontSize = 8.sp) }
            }

            Text("Level: ${generatorLevel.toInt()} dB", fontSize = 8.sp)
            Slider(
                value = generatorLevel,
                onValueChange = { onGeneratorLevelChanged(it) },
                valueRange = -60f..0f,
                modifier = Modifier.height(16.dp)
            )

            Button(
                onClick = onToggleGenerator,
                colors = ButtonDefaults.buttonColors(containerColor = if (isGeneratorRunning) Color(0xFFB00020) else Color(0xFF008000)),
                modifier = Modifier.fillMaxWidth().height(28.dp),
                contentPadding = PaddingValues(0.dp)
            ) {
                Text(if (isGeneratorRunning) "STOP OUTPUT" else "START OUTPUT", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
        }
    }

    if (showDeviceSettings) {
        AlertDialog(
            onDismissRequest = { showDeviceSettings = false },
            title = { Text("Device Setup & Routing", fontSize = 14.sp, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Input Device (USB Soundcard / Mic):", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    val inputOptions = listOf("Default Built-in Mic", "USB Audio Device (Ext Soundcard Ch 1)", "USB Audio Device (Ext Soundcard Ch 2)")
                    inputOptions.forEach { option ->
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                            RadioButton(selected = selectedInputDevice == option, onClick = { onInputDeviceSelected(option) })
                            Text(option, fontSize = 11.sp)
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Output Device (Speaker / Amp):", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    val outputOptions = listOf("Built-in Speaker", "USB Audio Output", "Bluetooth Audio")
                    outputOptions.forEach { option ->
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                            RadioButton(selected = selectedOutputDevice == option, onClick = { onOutputDeviceSelected(option) })
                            Text(option, fontSize = 11.sp)
                        }
                    }
                }
            },
            confirmButton = { Button(onClick = { showDeviceSettings = false }) { Text("Apply & Close") } }
        )
    }

    if (showCapturedDialog) {
        AlertDialog(
            onDismissRequest = { showCapturedDialog = false },
            title = { Text("Captured Graphic Traces", fontSize = 14.sp, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (capturedTraces.isEmpty()) {
                        Text("No traces captured yet. Click 'Capture Graphic' on the left panel.", fontSize = 11.sp)
                    } else {
                        Text("Total stored traces: ${capturedTraces.size}", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        capturedTraces.forEachIndexed { index, (name, _) ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("• $name", fontSize = 10.sp)
                                TextButton(onClick = { capturedTraces.removeAt(index) }) {
                                    Text("Delete", fontSize = 9.sp, color = Color.Red)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = { showCapturedDialog = false }) { Text("Close") }
            }
        )
    }

    if (showAutoEqDialog) {
        AlertDialog(
            onDismissRequest = { showAutoEqDialog = false },
            title = { Text("Auto EQ Preset (12 Band)", fontSize = 14.sp, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(peqBandsText, fontSize = 11.sp)
                    Text("Target standard: Flat (0dB response). Preset ready to export.", fontSize = 10.sp, color = Color.Gray)
                }
            },
            confirmButton = {
                Button(onClick = { showAutoEqDialog = false }) { Text("Export & Close") }
            }
        )
    }
}
