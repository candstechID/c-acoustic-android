package com.candtech.acoustic.ui

import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.candtech.acoustic.R
import kotlin.random.Random

@Composable
fun SmaartMainScreen(
    magnitude: FloatArray,
    phase: FloatArray,
    etc: FloatArray,
    peakFreq: Float,
    peakDb: Float,
    selectedInputDevice: String,
    onInputDeviceSelected: (String) -> Unit,
    selectedOutputDevice: String,
    onOutputDeviceSelected: (String) -> Unit,
    generatorType: String,
    onGeneratorTypeChanged: (String) -> Unit,
    generatorLevel: Float,
    onGeneratorLevelChanged: (Float) -> Unit,
    isGeneratorRunning: Boolean,
    onToggleGenerator: () -> Unit,
    isMeasuring: Boolean,
    onToggleMeasuring: () -> Unit
) {
    val context = LocalContext.current
    var showDeviceSettings by remember { mutableStateOf(false) }
    var autoPhaseResult by remember { mutableStateOf("Delay: 2.18 ms (0.75m) | Normal") }
    var showAutoEqDialog by remember { mutableStateOf(false) }
    var peqBandsText by remember { mutableStateOf("Ready to generate 12-band PEQ target flat standard.") }
    
    val capturedTraces = remember { mutableStateListOf<Pair<String, FloatArray>>() }
    var showCapturedDialog by remember { mutableStateOf(false) }

    Row(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFE0E0E0))
    ) {
        // PANEL KIRI
        Column(
            modifier = Modifier
                .weight(0.18f)
                .fillMaxHeight()
                .background(Color(0xFFCCCCCC))
                .border(1.dp, Color.Gray)
                .padding(6.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                modifier = Modifier.fillMaxWidth().background(Color.White).padding(4.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.cand_tech_logo),
                    contentDescription = "CANDSTECH Logo",
                    modifier = Modifier.height(24.dp).width(70.dp)
                )
                Text("CANDS RT", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color.DarkGray)
            }
            Divider(color = Color.Gray)
            Text("Session Data & Trace", fontWeight = FontWeight.Bold, fontSize = 10.sp, color = Color.Black)
            
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier.fillMaxWidth().height(65.dp)
            ) {
                Column(modifier = Modifier.padding(4.dp)) {
                    Text("PEQ Peak Live:", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Color.Red)
                    Text(String.format("🎯 %.1f Hz", peakFreq), fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.DarkGray)
                    Text(String.format("🔊 %.1f dB", peakDb), fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Blue)
                }
            }

            Button(
                onClick = {
                    val traceName = "Trace #${capturedTraces.size + 1}"
                    capturedTraces.add(Pair(traceName, magnitude.clone()))
                    Toast.makeText(context, "Captured: $traceName", Toast.LENGTH_SHORT).show()
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00796B)),
                modifier = Modifier.fillMaxWidth().height(30.dp),
                contentPadding = PaddingValues(0.dp)
            ) {
                Text("📸 Capture Graphic", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }

            Button(
                onClick = { showCapturedDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray),
                modifier = Modifier.fillMaxWidth().height(26.dp),
                contentPadding = PaddingValues(0.dp)
            ) {
                Text("📂 View Traces (${capturedTraces.size})", fontSize = 9.sp)
            }

            Spacer(modifier = Modifier.weight(1f))
            Button(
                onClick = { showDeviceSettings = true },
                colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray),
                modifier = Modifier.fillMaxWidth().height(32.dp),
                contentPadding = PaddingValues(0.dp)
            ) {
                Text("⚙ Device Setup", fontSize = 10.sp)
            }
        }

        // PANEL TENGAH (GRAFIK DENGAN LIVE PEAK FREQ & DB NUMBERS)
        Column(
            modifier = Modifier
                .weight(0.60f)
                .fillMaxHeight()
                .background(Color(0xFFEFEFEF))
                .border(1.dp, Color.Gray)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFFD6D6D6))
                    .padding(4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(String.format("Live Peak -> Freq: %.1f Hz | Level: %.1f dB", peakFreq, peakDb), fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Red)
                val statusText = if (isMeasuring) "🟢 Measuring Active" else "🔴 Stopped"
                Text(statusText, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = if (isMeasuring) Color(0xFF008000) else Color.Red)
            }

            // 1. IMPULSE RESPONSE (ETC)
            Box(modifier = Modifier.weight(0.25f).fillMaxWidth().border(0.5.dp, Color.LightGray).background(Color(0xFF141414))) {
                Column(modifier = Modifier.padding(4.dp).fillMaxSize()) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Impulse Response (ETC)", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.Green)
                        Text("0ms | 25ms | 50ms | 75ms | 100ms", fontSize = 8.sp, color = Color.LightGray)
                    }
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        for (yStep in 1..3) {
                            drawLine(Color.DarkGray, Offset(0f, size.height * (yStep / 4f)), Offset(size.width, size.height * (yStep / 4f)), strokeWidth = 1f)
                        }
                        for (xStep in 1..4) {
                            drawLine(Color.DarkGray, Offset(size.width * (xStep / 5f), 0f), Offset(size.width * (xStep / 5f), size.height), strokeWidth = 1f)
                        }
                        val stepX = size.width / etc.size
                        for (i in 0 until etc.size - 1) {
                            drawLine(
                                color = Color(0xFF00FF00),
                                start = Offset(i * stepX, size.height - (etc[i] * size.height)),
                                end = Offset((i + 1) * stepX, size.height - (etc[i + 1] * size.height)),
                                strokeWidth = 2f
                            )
                        }
                    }
                }
            }

            // 2. PHASE (Deg)
            Box(modifier = Modifier.weight(0.37f).fillMaxWidth().border(0.5.dp, Color.LightGray).background(Color(0xFF141414))) {
                Column(modifier = Modifier.padding(4.dp).fillMaxSize()) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Phase (Deg)", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.Cyan)
                        Text("+180° | 90° | 0° | -90° | -180°", fontSize = 8.sp, color = Color.LightGray)
                    }
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        drawLine(Color.Gray, Offset(0f, size.height / 2f), Offset(size.width, size.height / 2f), strokeWidth = 1f, strokePathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f))
                        for (xStep in 1..4) {
                            drawLine(Color.DarkGray, Offset(size.width * (xStep / 5f), 0f), Offset(size.width * (xStep / 5f), size.height), strokeWidth = 1f)
                        }
                        val stepX = size.width / phase.size
                        for (i in 0 until phase.size - 1) {
                            drawLine(
                                color = Color(0xFF00E5FF),
                                start = Offset(i * stepX, size.height - (phase[i] * size.height)),
                                end = Offset((i + 1) * stepX, size.height - (phase[i + 1] * size.height)),
                                strokeWidth = 2f
                            )
                        }
                    }
                }
            }

            // 3. MAGNITUDE (dB) & RTA WITH PEAK MARKER
            Box(modifier = Modifier.weight(0.38f).fillMaxWidth().border(0.5.dp, Color.LightGray).background(Color(0xFF141414))) {
                Column(modifier = Modifier.padding(4.dp).fillMaxSize()) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(String.format("Magnitude RTA | PEQ Peak: %.1f Hz (%.1f dB)", peakFreq, peakDb), fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.Yellow)
                        Text("20Hz | 100Hz | 1kHz | 10kHz | 20kHz", fontSize = 8.sp, color = Color.LightGray)
                    }
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val dbLevels = listOf(0.25f, 0.5f, 0.75f)
                        dbLevels.forEach { lvl ->
                            drawLine(Color.DarkGray, Offset(0f, size.height * lvl), Offset(size.width, size.height * lvl), strokeWidth = 1f)
                        }
                        for (xStep in 1..4) {
                            drawLine(Color.DarkGray, Offset(size.width * (xStep / 5f), 0f), Offset(size.width * (xStep / 5f), size.height), strokeWidth = 1f)
                        }

                        val stepX = size.width / magnitude.size
                        for (i in 0 until magnitude.size - 1) {
                            drawLine(
                                color = Color(0xFFFF3D00),
                                start = Offset(i * stepX, size.height - (magnitude[i] * size.height)),
                                end = Offset((i + 1) * stepX, size.height - (magnitude[i + 1] * size.height)),
                                strokeWidth = 2.5f
                            )
                        }
                    }
                }
            }
        }

        // PANEL KANAN (WORKFLOW & START MEASUREMENT)
        Column(
            modifier = Modifier
                .weight(0.22f)
                .fillMaxHeight()
                .background(Color(0xFFDCDCDC))
                .border(1.dp, Color.Gray)
                .padding(6.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text("Workflow Tuning", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color.Black)
            
            Button(
                onClick = onToggleMeasuring,
                colors = ButtonDefaults.buttonColors(containerColor = if (isMeasuring) Color(0xFFC62828) else Color(0xFF2E7D32)),
                modifier = Modifier.fillMaxWidth().height(30.dp),
                contentPadding = PaddingValues(0.dp)
            ) {
                Text(if (isMeasuring) "⏹ STOP MEASUREMENT" else "▶ START MEASUREMENT", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }

            Button(
                onClick = {
                    val randomMs = 1.0f + Random.nextFloat() * 4.0f
                    val randomM = randomMs * 0.343f
                    autoPhaseResult = String.format("Delay: %.2f ms (%.2f m) | Normal", randomMs, randomM)
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray),
                modifier = Modifier.fillMaxWidth().height(26.dp),
                contentPadding = PaddingValues(0.dp)
            ) {
                Text("⚡ Auto Phase & Delay", fontSize = 9.sp)
            }
            Text(autoPhaseResult, fontSize = 8.sp, color = Color.Blue, fontWeight = FontWeight.Bold)

            Button(
                onClick = {
                    peqBandsText = String.format("PEQ Target Peak @ %.1fHz (%.1fdB) -> Flat 0dB", peakFreq, peakDb)
                    showAutoEqDialog = true
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00AEEF)),
                modifier = Modifier.fillMaxWidth().height(26.dp),
                contentPadding = PaddingValues(0.dp)
            ) {
                Text("✨ Generate Auto EQ", fontSize = 9.sp, fontWeight = FontWeight.Bold)
            }

            Divider(color = Color.Gray, thickness = 1.dp)
            Text("Signal Generator", fontWeight = FontWeight.Bold, fontSize = 10.sp)
            
            Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                Button(
                    onClick = { onGeneratorTypeChanged("Pink Noise") },
                    colors = ButtonDefaults.buttonColors(containerColor = if(generatorType == "Pink Noise") Color.DarkGray else Color.LightGray),
                    modifier = Modifier.weight(1f).height(24.dp),
                    contentPadding = PaddingValues(0.dp)
                ) { Text("Pink", fontSize = 8.sp) }
                Button(
                    onClick = { onGeneratorTypeChanged("Sine Sweep") },
                    colors = ButtonDefaults.buttonColors(containerColor = if(generatorType == "Sine Sweep") Color.DarkGray else Color.LightGray),
                    modifier = Modifier.weight(1f).height(24.dp),
                    contentPadding = PaddingValues(0.dp)
                ) { Text("Sweep", fontSize = 8.sp) }
            }

            Text("Level: ${generatorLevel.toInt()} dB", fontSize = 8.sp)
            Slider(
                value = generatorLevel,
                onValueChange = { onGeneratorLevelChanged(it) },
                valueRange = -60f..0f,
                modifier = Modifier.height(16.dp)
            )

            Button(
                onClick = onToggleGenerator,
                colors = ButtonDefaults.buttonColors(containerColor = if (isGeneratorRunning) Color(0xFFB00020) else Color(0xFF008000)),
                modifier = Modifier.fillMaxWidth().height(28.dp),
                contentPadding = PaddingValues(0.dp)
            ) {
                Text(if (isGeneratorRunning) "STOP OUTPUT" else "START OUTPUT", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
        }
    }

    if (showDeviceSettings) {
        AlertDialog(
            onDismissRequest = { showDeviceSettings = false },
            title = { Text("Device Setup & Routing", fontSize = 14.sp, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Input Device (USB Soundcard / Mic):", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    val inputOptions = listOf("Default Built-in Mic", "USB Audio Device (Ext Soundcard Ch 1)")
                    inputOptions.forEach { option ->
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                            RadioButton(selected = selectedInputDevice == option, onClick = { onInputDeviceSelected(option) })
                            Text(option, fontSize = 11.sp)
                        }
                    }
                }
            },
            confirmButton = { Button(onClick = { showDeviceSettings = false }) { Text("Apply & Close") } }
        )
    }

    if (showCapturedDialog) {
        AlertDialog(
            onDismissRequest = { showCapturedDialog = false },
            title = { Text("Captured Traces", fontSize = 14.sp, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (capturedTraces.isEmpty()) {
                        Text("No traces captured yet.", fontSize = 11.sp)
                    } else {
                        capturedTraces.forEachIndexed { index, (name, _) ->
                            Text("• $name", fontSize = 10.sp)
                        }
                    }
                }
            },
            confirmButton = { Button(onClick = { showCapturedDialog = false }) { Text("Close") } }
        )
    }

    if (showAutoEqDialog) {
        AlertDialog(
            onDismissRequest = { showAutoEqDialog = false },
            title = { Text("Auto EQ Target Peak", fontSize = 14.sp, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(peqBandsText, fontSize = 11.sp)
                    Text(String.format("Detected Peak Frequency: %.1f Hz at Level: %.1f dB", peakFreq, peakDb), fontSize = 10.sp, color = Color.Gray)
                }
            },
            confirmButton = { Button(onClick = { showAutoEqDialog = false }) { Text("Export & Close") } }
        )
    }
}
