package com.candtech.acoustic.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun RTAScreen() {
    Column(modifier = Modifier.fillMaxSize().background(Color.White)) {
        TopBarWithLogo()
        Box(modifier = Modifier.weight(1f).fillMaxWidth().padding(16.dp)) {
            Text("Spectrum Analyzer (RTA) Visualizer Here", color = Color.Black)
        }
    }
}
