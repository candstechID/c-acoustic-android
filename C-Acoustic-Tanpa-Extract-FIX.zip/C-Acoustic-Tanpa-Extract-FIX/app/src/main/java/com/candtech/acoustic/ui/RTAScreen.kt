package com.candtech.acoustic.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun RTAScreen(liveAmplitudes: FloatArray, peakAmplitudes: FloatArray) {
    Column(modifier = Modifier.fillMaxSize().background(Color.White)) {
        TopBarWithLogo()
        
        Canvas(modifier = Modifier.weight(1f).fillMaxWidth().padding(16.dp)) {
            val bandCount = 31 // Standar 1/3 Octave
            val barWidth = size.width / bandCount
            
            for (i in 0 until bandCount) {
                // Bar Amplitudo Biru Smaart
                val barHeight = liveAmplitudes.getOrElse(i) { 0f } * size.height
                drawRect(
                    color = Color(0xFF00AEEF), 
                    topLeft = Offset(x = i * barWidth, y = size.height - barHeight),
                    size = Size(width = barWidth - 4f, height = barHeight)
                )
                
                // Garis Max Hold / Peak Merah
                val peakHeight = peakAmplitudes.getOrElse(i) { 0f } * size.height
                drawLine(
                    color = Color(0xFFFF0000), 
                    start = Offset(x = i * barWidth, y = size.height - peakHeight),
                    end = Offset(x = (i * barWidth) + (barWidth - 4f), y = size.height - peakHeight),
                    strokeWidth = 4f
                )
            }
        }
    }
}
