package com.candtech.acoustic.dsp
object AudioEngine {
    init { System.loadLibrary("cacoustic") }
    external fun init()
}
