package com.candtech.acoustic.dsp
object AudioEngine {
    init { System.loadLibrary("cacoustic") }
    external fun generateSineSweep()
    external fun calculateTransferFunction()
    external fun calculateAutoPhase(): FloatArray
    external fun generateAutoEQ(): FloatArray
}
