# C ACOUSTIC - CAND TECH RTA Analyzer (Android)
White SmaartLive 9 Style | Speaker Tuning Edition

![Logo](app/src/main/res/drawable/cand_tech_logo.png)

## Features Final (No Phantom Power)
- **USB External Soundcard Support** (UMC202HD, Scarlett, etc) - OTG
- **RTA** 1/3 Oct 20Hz-20kHz, FFT 8192, Z/A/C, Fast/Slow, Peak & Max Hold
- **Transfer Function** Dual Channel (Ref + Meas), Magnitude + Phase + Coherence
- **Impulse Response** Sine Sweep 20Hz-20kHz, ETC, Delay Finder (ms/m)
- **Auto Phase** Compare 2 Captures via Transfer Function - Auto Delay + Polarity Invert suggestion
- **Auto EQ** to Flat Standard - Generate 12 band PEQ, Safety +6dB/-12dB, Coherence gating
- **UI** White Theme #FFFFFF, Blue Bars, Logo CAND TECH Transparan Fix

## Workflow Tuning
Pink/Sweep -> USB Soundcard -> Speaker -> Mic RTA -> Capture A/B -> Auto Phase -> Auto EQ -> Export Preset

## Tech Stack
- Kotlin + Jetpack Compose
- Oboe / AAudio Low Latency
- Core Engine C++ Shared (RTA, TF, IR, AutoPhase, AutoEQ) via JNI
- USB Audio Device Selector

## How to Upload to GitHub Web
1. Buka github.com/new -> Create repository `c-acoustic-android`
2. Upload ZIP ini via web: Add file -> Upload files -> drag semua file dari ZIP ini
3. Commit

## Build
- Buka di Android Studio Hedgehog+
- Sync Gradle
- Run di HP Android dengan OTG USB Soundcard

## Project Structure
```
app/src/main/java/com/candtech/acoustic/
├── ui/ (RTA, Transfer, Impulse, AutoPhase, AutoEQ screens)
├── engine/ (AudioEngine, RTAEngine, TFEngine, IREngine, AutoPhaseEngine, AutoEQEngine)
├── usb/ (UsbAudioSelector)
└── MainActivity.kt

core/ (C++ Shared Engine - akan di-build sebagai .so)
├── audio_engine.cpp
├── transfer_function.cpp
├── impulse_response.cpp
├── auto_phase.cpp
└── auto_eq.cpp
```

## Owner
Candra Dwi Setiawan - CAND TECH - Surabaya
Logo ORY Fix: Gradien hitam tengah dipertahankan
